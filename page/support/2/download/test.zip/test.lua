-- スクリプトの開始時
function OnStart()
    -- (1) UIを作ってみる
    -- CreateUI()

    -- (2) カスタム変数を取得してみる
    -- GetData()

    -- (3) アニメーションを作ってみる
    CreateAnimation()
end

--#region (1) UIを作ってみる
function CreateUI()
    -- 画像テンプレートを作成
    local cat = game.InstantiateClientUIControl(1073741860, script.object)

    ---@cast cat ClientUIImageControl

    -- 画像ソースと画像IDを設定(にゃんこ)
    cat:SetImage(Enum.ImageSource.StaticReference, 112062)
    -- サイズ設定(にゃんこ)
    cat:SetSizeDelta(80, 80)
    -- 画像タイプ(にゃんこ)
    cat.imageType = Enum.ImageType.Basic
    -- 位置設定(にゃんこ)
    cat:SetAnchoredPosition(-700, 80)

    -- 画像テンプレートを作成
    local plate = game.InstantiateClientUIControl(1073741860, script.object)

    ---@cast plate ClientUIImageControl
    -- 画像ソースと画像IDを設定(プレート)
    plate:SetImage(Enum.ImageSource.StaticReference, 107201)
    -- サイズ設定(プレート)
    plate:SetSizeDelta(300, 80)
    -- 画像タイプ(プレート)
    plate.imageType = Enum.ImageType.Stretch
    -- 位置設定(プレート)
    plate:SetAnchoredPosition(-500, 90)

    -- テキストボックステンプレートを作成
    local hello = game.InstantiateClientUIControl(1073741862, script.object)

    ---@cast hello ClientUITextBoxControl
    -- テキスト設定(テキスト)
    hello.text = "こんにちは、にゃんこです"
    -- 文字色設定(テキスト)
    hello.fontColor = Color(147, 64, 64)
    -- 縁取りを有効にするかどうか(テキスト)
    hello.enableOutline = false
    -- 縦方向の揃え位置(テキスト)
    hello.verticalAlignment = Enum.TextVerticalAlignment.Middle
    -- 横方向の揃え位置(テキスト)
    hello.horizontalAlignment = Enum.TextHorizontalAlignment.Left
    -- サイズ設定(テキスト)
    hello:SetSizeDelta(260, 80)
    -- 位置設定(テキスト)
    hello:SetAnchoredPosition(-480, 90)
end

--#endregion

--#region (2) カスタム変数を取得してみる
function GetData()
    -- 画像テンプレートを作成
    local cat = game.InstantiateClientUIControl(1073741860, script.object)

    ---@cast cat ClientUIImageControl

    -- 画像ソースと画像IDを設定(にゃんこ)
    cat:SetImage(Enum.ImageSource.StaticReference, 112062)
    -- サイズ設定(にゃんこ)
    cat:SetSizeDelta(80, 80)
    -- 画像タイプ(にゃんこ)
    cat.imageType = Enum.ImageType.Basic
    -- 位置設定(にゃんこ)
    cat:SetAnchoredPosition(-700, 80)

    -- 画像テンプレートを作成
    local plate = game.InstantiateClientUIControl(1073741860, script.object)

    ---@cast plate ClientUIImageControl
    -- 画像ソースと画像IDを設定(プレート)
    plate:SetImage(Enum.ImageSource.StaticReference, 107201)
    -- サイズ設定(プレート)
    plate:SetSizeDelta(300, 80)
    -- 画像タイプ(プレート)
    plate.imageType = Enum.ImageType.Stretch
    -- 位置設定(プレート)
    plate:SetAnchoredPosition(-500, 90)

    -- テキストボックステンプレートを作成
    local hello = game.InstantiateClientUIControl(1073741862, script.object)

    ---@cast hello ClientUITextBoxControl

    -- テキスト設定(テキスト)
    hello.text = Calc()
    -- 文字色設定(テキスト)
    hello.fontColor = Color(147, 64, 64)
    -- 縁取りを有効にするかどうか(テキスト)
    hello.enableOutline = false
    -- 縦方向の揃え位置(テキスト)
    hello.verticalAlignment = Enum.TextVerticalAlignment.Middle
    -- 横方向の揃え位置(テキスト)
    hello.horizontalAlignment = Enum.TextHorizontalAlignment.Left
    -- サイズ設定(テキスト)
    hello:SetSizeDelta(260, 80)
    -- 位置設定(テキスト)
    hello:SetAnchoredPosition(-480, 90)

    -- カスタム変数の監視を登録
    script:RegisterCustomVariableChangedHandler(Enum.CustomVariableEntityType.PlayerSelf, "数字2",
        function(entityType, customVariableName)
            -- テキスト設定(テキスト)
            hello.text = Calc()
        end)
end

function Calc()
    -- カスタム変数を取得
    local num1 = game.GetGlobalCustomVariableValue(Enum.CustomVariableEntityType.PlayerSelf, "数字1")
    local num2 = game.GetGlobalCustomVariableValue(Enum.CustomVariableEntityType.PlayerSelf, "数字2")

    local result = num1 * num2

    -- 文字列結合
    local retunString = tostring(num1) .. " × " .. tostring(num2) .. " = " .. tostring(result)

    return retunString
end

--#endregion

--#region (3) アニメーションを作ってみる
function CreateAnimation()
    -- 画像テンプレートを作成
    local screen = game.InstantiateClientUIControl(1073741860, script.object)

    ---@cast screen ClientUIImageControl

    -- 画像ソースと画像IDを設定(スクリーン)
    screen:SetImage(Enum.ImageSource.StaticReference, 100001)
    -- 画像のカラーを設定(スクリーン)
    screen.imageColor = Color(0, 0, 0)
    -- サイズ設定(スクリーン)
    screen:SetSizeDelta(1600, 900)
    -- 画像タイプ(スクリーン)
    screen.imageType = Enum.ImageType.Basic
    -- マスキングを有効にするかどうか(スクリーン)
    screen.enableMask = true
    -- 塗りつぶしの形状(スクリーン)
    screen.fillType = Enum.ImageFillType.Radial360
    -- 	塗りつぶしの開始位置(180度,360度円軌道)(スクリーン)
    screen.fillRadialType = Enum.ImageFillRadialType.Top
    -- 進捗(スクリーン)
    screen.fillAmount = 0

    local tweenTable = { fillAmount = 1 }

    -- Tween作成
    local screenTween = game.Tween(screen, tweenTable, 2)

    screenTween:SetOnStepComplete(function()
        -- マスク反転するかどうかを反転(スクリーン)
        screen.reverseMaskArea = not screen.reverseMaskArea

        -- 進捗(スクリーン)
        screen.fillAmount = 0
    end)

    -- ループ回数を設定
    screenTween:SetLoops(-1)

    screenTween:SetRelative(true)

    -- Tween再生
    screenTween:Play()
end

--#endregion
