--------------------------------------------------
-- KeyboardKeyCode
--------------------------------------------------

---@class KeyboardKeyCode
---クリエイターキー1
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey1 = nil

---クリエイターキー2
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey2 = nil

---クリエイターキー3
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey3 = nil

---クリエイターキー4
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey4 = nil

---クリエイターキー5
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey5 = nil

---クリエイターキー6
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey6 = nil

---クリエイターキー7
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey7 = nil

---クリエイターキー8
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey8 = nil

---クリエイターキー9
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey9 = nil

---クリエイターキー10
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey10 = nil

---クリエイターキー11
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey11 = nil

---クリエイターキー12
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey12 = nil

---クリエイターキー13
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey13 = nil

---クリエイターキー14
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey14 = nil

---クリエイターキー15
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey15 = nil

---クリエイターキー16
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey16 = nil

---クリエイターキー17
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey17 = nil

---クリエイターキー18
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey18 = nil

---クリエイターキー19
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey19 = nil

---クリエイターキー20
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey20 = nil

---クリエイターキー21
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey21 = nil

---クリエイターキー22
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey22 = nil

---クリエイターキー23
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey23 = nil

---クリエイターキー24
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey24 = nil

---クリエイターキー25
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey25 = nil

---クリエイターキー26
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey26 = nil

---クリエイターキー27
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey27 = nil

---クリエイターキー28
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey28 = nil

---クリエイターキー29
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey29 = nil

---クリエイターキー30
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey30 = nil

---クリエイターキー31
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey31 = nil

---クリエイターキー32
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey32 = nil

---クリエイターキー33
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey33 = nil

---クリエイターキー34
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey34 = nil

---クリエイターキー35
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey35 = nil

---クリエイターキー36
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey36 = nil

---クリエイターキー37
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey37 = nil

---クリエイターキー38
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey38 = nil

---クリエイターキー39
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey39 = nil

---クリエイターキー40
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey40 = nil

---クリエイターキー41
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey41 = nil

---クリエイターキー42
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey42 = nil

---クリエイターキー43
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CraftspersonKey43 = nil

---前に移動
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.MoveForwardKey = nil

---後ろに移動
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.MoveBackwardKey = nil

---左に移動
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.MoveLeftKey = nil

---右に移動
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.MoveRightKey = nil

---歩く/走る状態を切り替える
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.SwitchToWalkOrRunKey = nil

---ダッシュ
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.SprintKey = nil

---ジャンプ
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.JumpKey = nil

---落下
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.DropKey = nil

---ショートカットルーレット呼出
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.OpenShortcutWheelKey = nil

---拾う/会話
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.InteractKey = nil

---通常攻撃
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.NormalAttackKey = nil

---キャラスキル1
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CharacterSkill1Key = nil

---キャラスキル2
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CharacterSkill2Key = nil

---キャラスキル3
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CharacterSkill3Key = nil

---キャラスキル4
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.CharacterSkill4Key = nil

---なし
---@type KeyboardKeyCode
Enum.KeyboardKeyCode.None = nil

--------------------------------------------------
-- ControllerKeyCode
--------------------------------------------------

---@class ControllerKeyCode
---クリエイターキー1
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey1 = nil

---クリエイターキー2
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey2 = nil

---クリエイターキー3
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey3 = nil

---クリエイターキー4
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey4 = nil

---クリエイターキー5
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey5 = nil

---クリエイターキー6
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey6 = nil

---クリエイターキー7
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey7 = nil

---クリエイターキー8
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey8 = nil

---クリエイターキー9
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey9 = nil

---クリエイターキー10
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey10 = nil

---クリエイターキー11
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey11 = nil

---クリエイターキー12
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey12 = nil

---クリエイターキー13
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey13 = nil

---クリエイターキー14
---@type ControllerKeyCode
Enum.ControllerKeyCode.CraftspersonKey14 = nil

---ダッシュ
---@type ControllerKeyCode
Enum.ControllerKeyCode.SprintKey = nil

---ジャンプ
---@type ControllerKeyCode
Enum.ControllerKeyCode.JumpKey = nil

---拾う/会話
---@type ControllerKeyCode
Enum.ControllerKeyCode.InteractKey = nil

---通常攻撃
---@type ControllerKeyCode
Enum.ControllerKeyCode.NormalAttackKey = nil

---キャラスキル1
---@type ControllerKeyCode
Enum.ControllerKeyCode.CharacterSkill1Key = nil

---キャラスキル2
---@type ControllerKeyCode
Enum.ControllerKeyCode.CharacterSkill2Key = nil

---キャラスキル3
---@type ControllerKeyCode
Enum.ControllerKeyCode.CharacterSkill3Key = nil

---キャラスキル4
---@type ControllerKeyCode
Enum.ControllerKeyCode.CharacterSkill4Key = nil

---メニュー決定
---@type ControllerKeyCode
Enum.ControllerKeyCode.MenuConfirmKey = nil

---メニュー戻る
---@type ControllerKeyCode
Enum.ControllerKeyCode.MenuBackKey = nil

---なし
---@type ControllerKeyCode
Enum.ControllerKeyCode.None = nil

--------------------------------------------------
-- KeyEventType
--------------------------------------------------
---@class KeyEventType
---キーボード&マウス:クリエイターキー1(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey1Down = nil

---キーボード&マウス:クリエイターキー2(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey2Down = nil

---キーボード&マウス:クリエイターキー3(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey3Down = nil

---キーボード&マウス:クリエイターキー4(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey4Down = nil

---キーボード&マウス:クリエイターキー5(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey5Down = nil

---キーボード&マウス:クリエイターキー6(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey6Down = nil

---キーボード&マウス:クリエイターキー7(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey7Down = nil

---キーボード&マウス:クリエイターキー8(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey8Down = nil

---キーボード&マウス:クリエイターキー9(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey9Down = nil

---キーボード&マウス:クリエイターキー10(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey10Down = nil

---キーボード&マウス:クリエイターキー11(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey11Down = nil

---キーボード&マウス:クリエイターキー12(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey12Down = nil

---キーボード&マウス:クリエイターキー13(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey13Down = nil

---キーボード&マウス:クリエイターキー14(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey14Down = nil

---キーボード&マウス:クリエイターキー15(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey15Down = nil

---キーボード&マウス:クリエイターキー16(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey16Down = nil

---キーボード&マウス:クリエイターキー17(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey17Down = nil

---キーボード&マウス:クリエイターキー18(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey18Down = nil

---キーボード&マウス:クリエイターキー19(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey19Down = nil

---キーボード&マウス:クリエイターキー20(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey20Down = nil

---キーボード&マウス:クリエイターキー21(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey21Down = nil

---キーボード&マウス:クリエイターキー22(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey22Down = nil

---キーボード&マウス:クリエイターキー23(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey23Down = nil

---キーボード&マウス:クリエイターキー24(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey24Down = nil

---キーボード&マウス:クリエイターキー25(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey25Down = nil

---キーボード&マウス:クリエイターキー26(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey26Down = nil

---キーボード&マウス:クリエイターキー27(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey27Down = nil

---キーボード&マウス:クリエイターキー28(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey28Down = nil

---キーボード&マウス:クリエイターキー29(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey29Down = nil

---キーボード&マウス:クリエイターキー30(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey30Down = nil

---キーボード&マウス:クリエイターキー31(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey31Down = nil

---キーボード&マウス:クリエイターキー32(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey32Down = nil

---キーボード&マウス:クリエイターキー33(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey33Down = nil

---キーボード&マウス:クリエイターキー34(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey34Down = nil

---キーボード&マウス:クリエイターキー35(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey35Down = nil

---キーボード&マウス:クリエイターキー36(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey36Down = nil

---キーボード&マウス:クリエイターキー37(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey37Down = nil

---キーボード&マウス:クリエイターキー38(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey38Down = nil

---キーボード&マウス:クリエイターキー39(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey39Down = nil

---キーボード&マウス:クリエイターキー40(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey40Down = nil

---キーボード&マウス:クリエイターキー41(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey41Down = nil

---キーボード&マウス:クリエイターキー42(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey42Down = nil

---キーボード&マウス:クリエイターキー43(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey43Down = nil

---キーボード&マウス:前に移動(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardMoveForwardKeyDown = nil

---キーボード&マウス:後ろに移動(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardMoveBackwardKeyDown = nil

---キーボード&マウス:左に移動(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardMoveLeftKeyDown = nil

---キーボード&マウス:右に移動(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardMoveRightKeyDown = nil

---キーボード&マウス:歩く/走る状態を切り替える(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardSwitchToWalkOrRunKeyDown = nil

---キーボード&マウス:ダッシュ(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardSprintKeyDown = nil

---キーボード&マウス:ジャンプ(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardJumpKeyDown = nil

---キーボード&マウス:落下(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardDropKeyDown = nil

---キーボード&マウス:ショートカットルーレット呼出(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardOpenShortcutWheelKeyDown = nil

---キーボード&マウス:拾う/会話(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardInteractKeyDown = nil

---キーボード&通常攻撃(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardNormalAttackKeyDown = nil

---キーボード&マウス:キャラスキル1(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCharacterSkill1KeyDown = nil

---キーボード&マウス:キャラスキル2(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCharacterSkill2KeyDown = nil

---キーボード&マウス:キャラスキル3(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCharacterSkill3KeyDown = nil

---キーボード&マウス:キャラスキル4(押下)
---@type KeyEventType
Enum.KeyEventType.KeyboardCharacterSkill4KeyDown = nil

---キーボード&マウス:クリエイターキー1(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey1Up = nil

---キーボード&マウス:クリエイターキー2(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey2Up = nil

---キーボード&マウス:クリエイターキー3(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey3Up = nil

---キーボード&マウス:クリエイターキー4(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey4Up = nil

---キーボード&マウス:クリエイターキー5(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey5Up = nil

---キーボード&マウス:クリエイターキー6(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey6Up = nil

---キーボード&マウス:クリエイターキー7(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey7Up = nil

---キーボード&マウス:クリエイターキー8(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey8Up = nil

---キーボード&マウス:クリエイターキー9(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey9Up = nil

---キーボード&マウス:クリエイターキー10(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey10Up = nil

---キーボード&マウス:クリエイターキー11(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey11Up = nil

---キーボード&マウス:クリエイターキー12(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey12Up = nil

---キーボード&マウス:クリエイターキー13(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey13Up = nil

---キーボード&マウス:クリエイターキー14(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey14Up = nil

---キーボード&マウス:クリエイターキー15(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey15Up = nil

---キーボード&マウス:クリエイターキー16(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey16Up = nil

---キーボード&マウス:クリエイターキー17(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey17Up = nil

---キーボード&マウス:クリエイターキー18(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey18Up = nil

---キーボード&マウス:クリエイターキー19(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey19Up = nil

---キーボード&マウス:クリエイターキー20(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey20Up = nil

---キーボード&マウス:クリエイターキー21(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey21Up = nil

---キーボード&マウス:クリエイターキー22(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey22Up = nil

---キーボード&マウス:クリエイターキー23(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey23Up = nil

---キーボード&マウス:クリエイターキー24(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey24Up = nil

---キーボード&マウス:クリエイターキー25(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey25Up = nil

---キーボード&マウス:クリエイターキー26(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey26Up = nil

---キーボード&マウス:クリエイターキー27(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey27Up = nil

---キーボード&マウス:クリエイターキー28(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey28Up = nil

---キーボード&マウス:クリエイターキー29(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey29Up = nil

---キーボード&マウス:クリエイターキー30(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey30Up = nil

---キーボード&マウス:クリエイターキー31(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey31Up = nil

---キーボード&マウス:クリエイターキー32(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey32Up = nil

---キーボード&マウス:クリエイターキー33(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey33Up = nil

---キーボード&マウス:クリエイターキー34(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey34Up = nil

---キーボード&マウス:クリエイターキー35(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey35Up = nil

---キーボード&マウス:クリエイターキー36(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey36Up = nil

---キーボード&マウス:クリエイターキー37(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey37Up = nil

---キーボード&マウス:クリエイターキー38(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey38Up = nil

---キーボード&マウス:クリエイターキー39(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey39Up = nil

---キーボード&マウス:クリエイターキー40(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey40Up = nil

---キーボード&マウス:クリエイターキー41(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey41Up = nil

---キーボード&マウス:クリエイターキー42(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey42Up = nil

---キーボード&マウス:クリエイターキー43(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCraftspersonKey43Up = nil

---キーボード&マウス:前に移動(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardMoveForwardKeyUp = nil

---キーボード&マウス:後ろに移動(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardMoveBackwardKeyUp = nil

---キーボード&マウス:左に移動(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardMoveLeftKeyUp = nil

---キーボード&マウス:右に移動(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardMoveRightKeyUp = nil

---キーボード&マウス:歩く/走る状態を切り替える(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardSwitchToWalkOrRunKeyUp = nil

---キーボード&マウス:ダッシュ(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardSprintKeyUp = nil

---キーボード&マウス:ジャンプ(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardJumpKeyUp = nil

---キーボード&マウス:落下(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardDropKeyUp = nil

---キーボード&マウス:ショートカットルーレット呼出(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardOpenShortcutWheelKeyUp = nil

---キーボード&マウス:拾う/会話(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardInteractKeyUp = nil

---キーボード&通常攻撃(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardNormalAttackKeyUp = nil

---キーボード&マウス:キャラスキル1(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCharacterSkill1KeyUp = nil

---キーボード&マウス:キャラスキル2(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCharacterSkill2KeyUp = nil

---キーボード&マウス:キャラスキル3(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCharacterSkill3KeyUp = nil

---キーボード&マウス:キャラスキル4(離す)
---@type KeyEventType
Enum.KeyEventType.KeyboardCharacterSkill4KeyUp = nil

---コントローラー:クリエイターキー1(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey1Down = nil

---コントローラー:クリエイターキー2(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey2Down = nil

---コントローラー:クリエイターキー3(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey3Down = nil

---コントローラー:クリエイターキー4(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey4Down = nil

---コントローラー:クリエイターキー5(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey5Down = nil

---コントローラー:クリエイターキー6(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey6Down = nil

---コントローラー:クリエイターキー7(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey7Down = nil

---コントローラー:クリエイターキー8(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey8Down = nil

---コントローラー:クリエイターキー9(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey9Down = nil

---コントローラー:クリエイターキー10(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey10Down = nil

---コントローラー:クリエイターキー11(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey11Down = nil

---コントローラー:クリエイターキー12(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey12Down = nil

---コントローラー:クリエイターキー13(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey13Down = nil

---コントローラー:クリエイターキー14(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey14Down = nil

---コントローラー:ダッシュ(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerSprintKeyDown = nil

---コントローラー:ジャンプ(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerJumpKeyDown = nil

---コントローラー:拾う/会話(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerInteractKeyDown = nil

---コントローラー:通常攻撃(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerNormalAttackKeyDown = nil

---コントローラー:キャラスキル1(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCharacterSkill1KeyDown = nil

---コントローラー:キャラスキル2(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCharacterSkill2KeyDown = nil

---コントローラー:キャラスキル3(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCharacterSkill3KeyDown = nil

---コントローラー:キャラスキル4(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerCharacterSkill4KeyDown = nil

---コントローラー:メニュー決定(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerMenuConfirmKeyDown = nil

---コントローラー:メニュー戻る(押下)
---@type KeyEventType
Enum.KeyEventType.ControllerMenuBackKeyDown = nil

---コントローラー:クリエイターキー1(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey1Up = nil

---コントローラー:クリエイターキー2(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey2Up = nil

---コントローラー:クリエイターキー3(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey3Up = nil

---コントローラー:クリエイターキー4(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey4Up = nil

---コントローラー:クリエイターキー5(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey5Up = nil

---コントローラー:クリエイターキー6(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey6Up = nil

---コントローラー:クリエイターキー7(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey7Up = nil

---コントローラー:クリエイターキー8(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey8Up = nil

---コントローラー:クリエイターキー9(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey9Up = nil

---コントローラー:クリエイターキー10(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey10Up = nil

---コントローラー:クリエイターキー11(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey11Up = nil

---コントローラー:クリエイターキー12(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey12Up = nil

---コントローラー:クリエイターキー13(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey13Up = nil

---コントローラー:クリエイターキー14(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCraftspersonKey14Up = nil

---コントローラー:ダッシュ(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerSprintKeyUp = nil

---コントローラー:ジャンプ(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerJumpKeyUp = nil

---コントローラー:拾う/会話(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerInteractKeyUp = nil

---コントローラー:通常攻撃(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerNormalAttackKeyUp = nil

---コントローラー:キャラスキル1(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCharacterSkill1KeyUp = nil

---コントローラー:キャラスキル2(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCharacterSkill2KeyUp = nil

---コントローラー:キャラスキル3(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCharacterSkill3KeyUp = nil

---コントローラー:キャラスキル4(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerCharacterSkill4KeyUp = nil

---コントローラー:メニュー決定(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerMenuConfirmKeyUp = nil

---コントローラー:メニュー戻る(離す)
---@type KeyEventType
Enum.KeyEventType.ControllerMenuBackKeyUp = nil
