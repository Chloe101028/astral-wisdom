---@class ClientUIContainerControl : ClientUIBaseControl
---@field isolateNavigation boolean コントローラーナビゲーションを隔離するかどうか
---@field disableCursorEventPassthrough boolean ボタンイベントの貫通をブロックするかどうか
---@field disableKeyEventPassthrough boolean エリア内のポインターイベントの貫通をブロックするかどうか
---@field showCursor boolean ポインターを常時表示するかどうか
ClientUIContainerControl = {}
