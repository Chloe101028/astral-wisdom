---@meta

---@class ColorValue
ColorValue = {}

---@class Vector2
Vector2 = {}

---@class Vector3
Vector3 = {}

--------------------------------------------------
-- ColorValue
--------------------------------------------------

---@class ColorValue
---@field r number 赤
---@field g number 緑
---@field b number 青
---@field a number 透明度
ColorValue = {}

--------------------------------------------------
-- Vector2
--------------------------------------------------

---@class Vector2
---@field x number x
---@field y number y
Vector2 = {}

--------------------------------------------------
-- Vector3
--------------------------------------------------

---@class Vector3
---@field x number x
---@field y number y
---@field z number z
Vector3 = {}

--------------------------------------------------
-- EnumItem
--------------------------------------------------

---@class EnumItem
---@field name string 列挙値の名称
---@field FullName string 列挙値の完全名
---@field EnumType string 列挙型の名称
EnumItem = {}

--------------------------------------------------
-- Enum
--------------------------------------------------

---@class Enum
Enum = {}

Enum.EaseType = {}
Enum.CustomVariableEntityType = {}
Enum.Device = {}
Enum.StageMode = {}
Enum.LanguageType = {}

Enum.ParamType = {}
Enum.CursorEventType = {}
Enum.ScrollDirection = {}
Enum.ScrollLayoutConstraint = {}
Enum.ScrollAlignType = {}

Enum.ControllerNavigationDir = {}
Enum.ControllerNavigationEventType = {}
Enum.ControllerNavigationMode = {}
Enum.TextHorizontalAlignment = {}
Enum.TextVerticalAlignment = {}

Enum.ImageType = {}
Enum.ImageSource = {}
Enum.ImageFillType = {}
Enum.ImageFillHorizontalType = {}
Enum.ImageFillVerticalType = {}

Enum.ImageFillRadial90Type = {}
Enum.ImageFillRadialType = {}
Enum.ImageMaskSoftEdgeMode = {}
Enum.UIAnimationLayer = {}

Enum.KeyboardKeyCode = {}
Enum.ControllerKeyCode = {}
Enum.KeyEventType = {}

--------------------------------------------------
-- 型付け
--------------------------------------------------

---@type Script
script = script

---@type Game
game = game

---@type Enum
Enum = Enum
