---@class CursorEventData
---@field dragging boolean 現在ドラッグ中かどうか
---@field touchId integer タッチポイントID
CursorEventData = {}

---現在の画面のUI座標を取得
---@return number, number
function CursorEventData:GetUIPos()
    return 0, 0
end

---タッチした画面UI座標を取得
---@return number, number
function CursorEventData:GetPressUIPos()
    return 0, 0
end

---今回のイベントにおける画面UIの移動量を取得
---@return number, number
function CursorEventData:GetUIPosDelta()
    return 0, 0
end
