---@class Game
game = {}

---【★】テンプレートから親の下にUI作成
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@param prefabIndex integer テンプレートインデックス
---@param parent ClientUIBaseControl 親UIコントロール
---@return ClientUIBaseControl
function game.InstantiateClientUIControl(
    prefabIndex,
    parent
)
    return {}
end

---指定したUIを破棄
---@param control ClientUIBaseControl UIコントロール
function game.DestroyClientUIControl(control) end

---【★】実行IDからUIを取得
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@param controlId integer 実行ID
---@return ClientUIBaseControl
function game.GetClientUIControl(controlId)
    return {}
end

---【★】指定UIのルートを取得
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@param name string UIパス
---@return ClientUIBaseControl
function game.FindClientUIRoot(name)
    return {}
end

---【★】すべてのUIのルートを取得
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@return ClientUIBaseControl[]
function game.GetClientUIRoots()
    return {}
end

---画面解像度に応じたUI領域の幅と高さを取得
---@return number,number
function game.GetUICanvasSize()
    return 0, 0
end

---カーソルのUI座標を取得
---@return number,number
function game.GetCursorUIPos()
    return 0, 0
end

--- 現在の入力デバイスを取得
---@return Device
function game.GetDevice()
    return Enum.Device.Controller
end

---コントローラーのフォーカスを設定
---@param control ClientUIBaseControl UIコントロール
function game.SetControllerFocus(control) end

---【★】現在のコントローラーのフォーカスを取得
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@return ClientUIBaseControl
function game.GetControllerFocus()
    return {}
end

---左スティックの軸値を取得
---@return Vector2
function game.GetControllerLeftStickAxis()
    return {}
end

---右スティックの軸値を取得
---@return Vector2
function game.GetControllerRightStickAxis()
    return {}
end

---Tweenアニメーションを作成
---@param target any 対象オブジェクト
---@param data table Tween可能なフィールド名をキーとし目標値を値としたテーブル
---@param duration number 継続時間
---@return Tween
function game.Tween(target, data, duration)
    return Tween
end

---空のTweenアニメーションシーケンスを作成
---@return TweenSequence
function game.TweenSequence()
    return TweenSequence
end

---サーバーへ信号を送信
---@param signalName string 信号名
---@return ServerSignal
function game.ServerSignal(signalName)
    return ServerSignal
end

---カスタム変数を取得
---@param entityType CustomVariableEntityType エンティティタイプ
---@param variableName string カスタム変数名
---@return any
function game.GetGlobalCustomVariableValue(
    entityType,
    variableName
)
end

---1人プレイモードでステージの時間停止状態を設定
---@param pause boolean true:有効 false:無効
function game.PauseLevelTime(pause) end

---ステージが時間停止状態にあるかどうか
---@return boolean
function game.IsLevelTimePaused()
    return true
end

---2D効果音を再生
---@param audioId integer 効果音ID
---@return integer
function game.PlayAudio2D(audioId)
    return 0
end

---指定した効果音の停止
---@param audioInstanceId integer 効果音インスタンスID
function game.StopAudio(audioInstanceId) end

---効果音インスタンスが存在しているかどうか
---@param audioInstanceId integer 効果音インスタンスID
---@return boolean
function game.IsAudioAlive(audioInstanceId)
    return true
end

---現在の言語を取得
---@return LanguageType
function game.GetLanguageType()
    return Enum.LanguageType.LanguageNone
end

---現在のステージモードを取得
---@return StageMode
function game.GetStageMode()
    return Enum.StageMode.Beyond
end

---現在テストプレイ中かどうか
---@return boolean
function game.IsTestPlay()
    return true
end

---ローカライズテキストを取得
---@param textMapId string テキストマッピングID
---@return string
function game.GetText(textMapId)
    return ""
end
