---@class TweenSequence
TweenSequence = {}

---シーケンスの末尾にTweenを追加
---@param tween Tween Tween
---@return TweenSequence
function TweenSequence:Append(tween)
    return {}
end

---シーケンスの末尾に指定した秒数の待機時間を追加
---@param time number 待機時間
---@return TweenSequence
function TweenSequence:AppendInterval(time)
    return {}
end

---シーケンスの末尾にコールバックを追加
---@param callback fun() コールバック
---@return TweenSequence
function TweenSequence:AppendCallback(callback)
    return {}
end

---現在の末尾のステップと同時に再生
---@param tween Tween Tween
---@return TweenSequence
function TweenSequence:Join(tween)
    return {}
end

---指定した時間にTweenを挿入
---@param time number 指定時間
---@param tween Tween Tween
---@return TweenSequence
function TweenSequence:Insert(time, tween)
    return {}
end

---指定した時間にコールバックを挿入
---@param time number 指定時間
---@param callback fun() コールバック
---@return TweenSequence
function TweenSequence:InsertCallback(time, callback)
    return {}
end

---シーケンスの再生
---@return TweenSequence
function TweenSequence:Play()
    return {}
end

--シーケンスを一時停止
function TweenSequence:Pause() end

---シーケンスを再開
function TweenSequence:Resume() end

---最初から再生
function TweenSequence:Restart() end

---シーケンスを終了
function TweenSequence:Complete() end

---シーケンスを破棄
---@param complete boolean true:完了のコールバックあり false:完了のコールバックなし
function TweenSequence:Kill(complete) end

--- シーケンス完了時に呼び出されるコールバックを設定
---@param onComplete fun() コールバック
---@return TweenSequence
function TweenSequence:SetOnComplete(onComplete)
    return {}
end

--- ステップ完了時に呼び出されるコールバックを設定
---@param onStepComplete fun() コールバック
---@return TweenSequence
function TweenSequence:SetOnStepComplete(onStepComplete)
    return {}
end

--- ループ回数を設定
---@param times integer ループ回数
---@return TweenSequence
function TweenSequence:SetLoops(times)
    return {}
end
