--------------------------------------------------
-- ライフサイクル
--------------------------------------------------

---スクリプトの初期化時
function OnInit()
end

---スクリプトの起動時
function OnStart()
end

---スクリプトの有効化時
function OnEnable()
end

---スクリプトの無効化時
function OnDisable()
end

---毎フレーム(ステージの時間停止の影響なし)
---@param dt number 前回のフレームから今回のフレームまでに経過した時間
function OnUpdate(dt)
end

---毎フレーム(ステージの時間停止の影響あり)
---@param dt number 前回のフレームから今回のフレームまでに経過した時間
function OnLevelUpdate(dt)
end

---スクリプトの破棄時
function OnDestroy()
end
