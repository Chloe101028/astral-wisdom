--------------------------------------------------
-- グローバルAPI
--------------------------------------------------

---オブジェクトの型を取得
---@param value any オブジェクト
---@return string
function typeof(value)
    return ""
end

---	通常ログを出力
---@param ... any
function print(...)
end

---エラーログを出力
---@param ... any
function printerr(...)
end

---@class debug
debug = {}

--標準ライブラリと重複するため削除
-----スタックトレースを取得
-----@param message? string
-----@param level? integer
-----@return string
--function debug.traceback(message, level)
--    return ""
--end

---現在のクライアントコントロールの階層構造をログに出力
function game.PrintClientUITree()
end

---	引数が数値でないか判定
---@param n number
---@return boolean
function math.isnan(n)
    return true
end

---引数が正または負の無限大かどうかを判定
---@param n number
---@return boolean
function math.isinf(n)
    return true
end
