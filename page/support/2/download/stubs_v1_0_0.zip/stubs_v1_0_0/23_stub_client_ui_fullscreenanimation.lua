---@class ClientUIFullscreenAnimationControl : ClientUIBaseControl
---@field animationId integer 画面エフェクトのID
---@field playSoundEffect boolean 効果音を再生するかどうか
ClientUIFullscreenAnimationControl = {}
