--- 色情報
---@class Color
---@field r number 赤
---@field g number 緑
---@field b number 青
---@field a number 透明度
Color = {}

--- RGB値からColorValueを生成
---@param r number 赤(0～255)
---@param g number 緑(0～255)
---@param b number 青(0～255)
---@return ColorValue
function Color.FromRGB(r, g, b)
    return {}
end

--- RGBA値からColorValueを生成
---@param r number 赤(0～255)
---@param g number 緑(0～255)
---@param b number 青(0～255)
---@param a number? 透明度(0～255) 初期値:255(不透明)
---@return ColorValue
function Color.FromRGBA(r, g, b, a)
    return {}
end

---ColorValueをRGBA値に分解
---@param colorValue ColorValue ColorValue
---@return number,number,number,number
function Color.ToRGBA(colorValue)
    return 0, 0, 0, 0
end
