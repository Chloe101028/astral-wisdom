---@class Tween
Tween = {}

---変化の仕方を設定し、現在のインスタンスを返却
---@param easeType EaseType イージングオプション
---@return Tween
function Tween:SetEase(easeType)
    return Tween
end

---tweenDataTableにおける目標値の解釈方法を設定
---@param relative boolean true:絶対値 false:現在の値からの相対的な増量
---@return Tween
function Tween:SetRelative(relative)
    return Tween
end

---再生
---@return Tween
function Tween:Play()
    return Tween
end

---一時停止
function Tween:Pause() end

---一時停止した位置から再開
function Tween:Resume() end

---最初から再生
function Tween:Restart() end

---終了
function Tween:Complete() end

---インスタンスを破棄
---@param complete boolean true:完了のコールバックあり false:完了のコールバックなし
function Tween:Kill(complete) end

---	すべてのループが完了した後のコールバックを設定し、現在のインスタンスを返却
---@param callback fun()　コールバック
---@return Tween
function Tween:SetOnComplete(callback)
    return Tween
end

---ステップ完了時のコールバックを設定し、現在のインスタンスを返却
---@param callback fun() コールバック
---@return Tween
function Tween:SetOnStepComplete(callback)
    return Tween
end

---ループ回数を設定し、現在のインスタンスを返却
---@param count integer ループ回数
---@return Tween
function Tween:SetLoops(count)
    return Tween
end
