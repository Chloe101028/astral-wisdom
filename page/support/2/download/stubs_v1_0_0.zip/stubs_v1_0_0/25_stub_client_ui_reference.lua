---@class ClientUIReferenceControl : ClientUIBaseControl
---@field referencedPrefabIndex integer 参照するモジュールテンプレートのインデックス
ClientUIReferenceControl = {}
