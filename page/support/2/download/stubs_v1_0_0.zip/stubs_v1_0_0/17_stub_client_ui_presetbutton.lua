---@class ClientUIPresetButtonControl : ClientUIBaseControl
---@field interactable boolean ボタンの利用可否
---@field clickAudioId integer クリックの効果音のインデックス
---@field raycastTarget boolean ポインターのレイキャストで検出可能かどうか
ClientUIPresetButtonControl = {}

---監視するカーソルイベントを登録
---@param eventType CursorEventType イベントタイプ
---@param callback fun(cursorEventData:CursorEventData)
function ClientUIPresetButtonControl:AddCursorEventListener(
    eventType,
    callback
)
end

---監視中のカーソルイベントを解除
---@param eventType CursorEventType イベントタイプ
---@param callback fun(cursorEventData:CursorEventData)
function ClientUIPresetButtonControl:RemoveCursorEventListener(
    eventType,
    callback
)
end

---指定したカーソルイベントの監視を解除
---@param eventType CursorEventType イベントタイプ
function ClientUIPresetButtonControl:RemoveCursorEventListeners(
    eventType
)
end

---すべてのカーソルイベントの監視を解除
function ClientUIPresetButtonControl:RemoveAllCursorEventListeners()
end

---CursorDown、CursorUp、CursorClick を順に実行
function ClientUIPresetButtonControl:SimulateCursorClick()
end
