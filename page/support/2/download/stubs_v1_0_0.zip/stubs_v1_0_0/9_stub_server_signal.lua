---@class ServerSignal
ServerSignal = {}

---信号のパラメータを設定
---@param paramType ParamType パラメータタイプ
---@param paramValue any パラメータ値
function ServerSignal:AddParam(paramType, paramValue) end

---作成済みの信号を送信
function ServerSignal:SendSignal() end

---パラメータ(整数)を追加
---@param intValue integer パラメータ(整数)
function ServerSignal:AddInt(intValue) end

---パラメータ(整数リスト)を追加
---@param intListValue integer[] パラメータ(整数リスト)
function ServerSignal:AddIntList(intListValue) end

---パラメータ(浮動小数点数)を追加
---@param floatValue number パラメータ(浮動小数点数)
function ServerSignal:AddFloat(floatValue) end

---パラメータ(浮動小数点数リスト)を追加
---@param floatListValue number[] パラメータ(浮動小数点数リスト)
function ServerSignal:AddFloatList(floatListValue) end

---パラメータ(文字列)を追加
---@param stringValue string パラメータ(文字列)
function ServerSignal:AddString(stringValue) end

---パラメータ(文字列リスト)を追加
---@param stringListValue string[] パラメータ(文字列リスト)
function ServerSignal:AddStringList(stringListValue) end

---パラメータ(3Dベクトル)を追加
---@param vector3Value Vector3 パラメータ(3Dベクトル)
function ServerSignal:AddVector3(vector3Value) end

---パラメータ(3Dベクトルリスト)を追加
---@param vector3ListValue Vector3[] パラメータ(3Dベクトルリスト)
function ServerSignal:AddVector3List(vector3ListValue) end

---パラメータ(ブール値)を追加
---@param boolValue boolean パラメータ(ブール値)
function ServerSignal:AddBool(boolValue) end

---パラメータ(ブール値リスト)を追加
---@param boolListValue boolean[] パラメータ(ブール値リスト)
function ServerSignal:AddBoolList(boolListValue) end

---パラメータ(GUID)を追加
---@param guidValue integer パラメータ(GUID)
function ServerSignal:AddGuid(guidValue) end

---パラメータ(GUIDリスト)を追加
---@param guidListValue integer[] パラメータ(GUIDリスト)
function ServerSignal:AddGuidList(guidListValue) end

---パラメータ(エンティティ)を追加
---@param entityValue integer パラメータ(エンティティ)
function ServerSignal:AddEntity(entityValue) end

---パラメータ(エンティティリスト)を追加
---@param entityListValue integer[] パラメータ(エンティティリスト)
function ServerSignal:AddEntityList(entityListValue) end

---パラメータ(プレハブID)を追加
---@param prefabIdValue integer パラメータ(プレハブID)
function ServerSignal:AddPrefabId(prefabIdValue) end

---パラメータ(プレハブIDリスト)を追加
---@param prefabIdListValue integer[] パラメータ(プレハブIDリスト)
function ServerSignal:AddPrefabIdList(prefabIdListValue) end

---パラメータ(配置ID)を追加
---@param configIdValue integer パラメータ(配置ID)
function ServerSignal:AddConfigId(configIdValue) end

---パラメータ(配置IDリスト)を追加
---@param configIdListValue integer[] パラメータ(配置IDリスト)
function ServerSignal:AddConfigIdList(configIdListValue) end
