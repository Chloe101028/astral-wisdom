---@class ClientUIBaseControl
ClientUIBaseControl                    = {}

---コントロールが存在しているかどうか
---@type boolean
ClientUIBaseControl.alive              = true

---実行ID
---@type integer
ClientUIBaseControl.id                 = 0

---コントロールのテンプレートインデックス
---@type integer
ClientUIBaseControl.prefabIndex        = 0

---アクティブ状態
---@type boolean
ClientUIBaseControl.active             = true

---すべての親要素を考慮した実際のアクティブ状態
---@type boolean
ClientUIBaseControl.activeInHierarchy  = true

---表示状態
---@type boolean
ClientUIBaseControl.visible            = true

---コントロール名
---@type string
ClientUIBaseControl.name               = ""

---【★】親コントロール
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@type ClientUIBaseControl
ClientUIBaseControl.parent             = nil

---位置(x)
---@type number
ClientUIBaseControl.anchoredPositionX  = 0

---位置(y)
---@type number
ClientUIBaseControl.anchoredPositionY  = 0

---サイズ(x)
---@type number
ClientUIBaseControl.sizeDeltaX         = 0

---サイズ(y)
---@type number
ClientUIBaseControl.sizeDeltaY         = 0

---最小アンカー(x)
---@type number
ClientUIBaseControl.anchorMinX         = 0

---最小アンカー(y)
---@type number
ClientUIBaseControl.anchorMinY         = 0

---最大アンカー(x)
---@type number
ClientUIBaseControl.anchorMaxX         = 0

---最大アンカー(y)
---@type number
ClientUIBaseControl.anchorMaxY         = 0

---中心(x)
---@type number
ClientUIBaseControl.pivotX             = 0

---中心(y)
---@type number
ClientUIBaseControl.pivotY             = 0

---ズーム(x)
---@type number
ClientUIBaseControl.localScaleX        = 0

---ズーム(y)
---@type number
ClientUIBaseControl.localScaleY        = 0

---ズーム(z)
---@type number
ClientUIBaseControl.localScaleZ        = 0

---回転(x)
---@type number
ClientUIBaseControl.localRotationX     = 0

---回転(y)
---@type number
ClientUIBaseControl.localRotationY     = 0

---回転(z)
---@type number
ClientUIBaseControl.localRotationZ     = 0

---コントローラーのスティックによるナビゲーションで選択可能かどうか
---@type boolean
ClientUIBaseControl.canControllerFocus = true

---【★】子のコントロールを取得
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@return ClientUIBaseControl[]
function ClientUIBaseControl:GetChildren()
    return {}
end

---【★】カレントコントロール内の指定した名称の子のコントロールを取得
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@param name string コントロール名
---@return ClientUIBaseControl
function ClientUIBaseControl:GetChild(name)
    return ClientUIBaseControl
end

---【★】パスに基づいて子のコントロールを取得
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@param path string パス
---@return ClientUIBaseControl
function ClientUIBaseControl:FindChild(path)
    return ClientUIBaseControl
end

---アクティブ状態を設定
---@param active boolean true:アクティブ false:非アクティブ
function ClientUIBaseControl:SetActive(active) end

---表示状態を設定
---@param visible boolean true:表示 false:非表示
function ClientUIBaseControl:SetVisible(visible) end

---同階層内での並び順インデックスを取得
---@return integer
function ClientUIBaseControl:GetSiblingIndex()
    return 0
end

---同階層内での並び順インデックスを設定
---@param index integer インデックス
---@return boolean
function ClientUIBaseControl:SetSiblingIndex(index)
    return true
end

---同階層の先頭に移動
---@return boolean
function ClientUIBaseControl:SetAsFirstSibling()
    return true
end

---同階層の末尾に移動
---@return boolean
function ClientUIBaseControl:SetAsLastSibling()
    return true
end

---位置取得
---@return number,number
function ClientUIBaseControl:GetAnchoredPosition()
    return 0, 0
end

---位置設定
---@param x number 位置(x)
---@param y number 位置(y)
function ClientUIBaseControl:SetAnchoredPosition(x, y) end

---サイズ取得
---@return number,number
function ClientUIBaseControl:GetSizeDelta()
    return 0, 0
end

---サイズ設定
---@param x number サイズ(x)
---@param y number サイズ(y)
function ClientUIBaseControl:SetSizeDelta(x, y) end

---最小アンカー取得
---@return number,number
function ClientUIBaseControl:GetAnchorMin()
    return 0, 0
end

---最小アンカーの設定
---@param x number 最小アンカー(x)
---@param y number 最小アンカー(y)
function ClientUIBaseControl:SetAnchorMin(x, y) end

---最大アンカー取得
---@return number,number
function ClientUIBaseControl:GetAnchorMax()
    return 0, 0
end

---最大アンカーの設定
---@param x number 最大アンカー(x)
---@param y number 最大アンカー(y)
function ClientUIBaseControl:SetAnchorMax(x, y) end

---中心取得
---@return number,number
function ClientUIBaseControl:GetPivot()
    return 0, 0
end

---中心の設定
---@param x number 中心(x)
---@param y number 中心(y)
function ClientUIBaseControl:SetPivot(x, y) end

---ズーム比取得
---@return number,number,number
function ClientUIBaseControl:GetLocalScale()
    return 0, 0, 0
end

---ズーム比の設定
---@param x number ズーム比(x)
---@param y number ズーム比(y)
---@param z number ズーム比(z)
function ClientUIBaseControl:SetLocalScale(x, y, z) end

---回転取得
---@return number,number,number
function ClientUIBaseControl:GetLocalRotation()
    return 0, 0, 0
end

---回転の設定
---@param x number 回転(x)
---@param y number 回転(y)
---@param z number 回転(z)
function ClientUIBaseControl:SetLocalRotation(x, y, z) end

---パス指定で紐づけられているスクリプトを取得
---@param path string パス
---@return Script
function ClientUIBaseControl:GetScriptByPath(path)
    return {}
end

---スクリプトマッピングIDでスクリプトを取得
---@param scriptMappingId integer スクリプトマッピングID
---@return Script
function ClientUIBaseControl:GetScript(scriptMappingId)
    return {}
end

---コントロール上のすべてのスクリプトを取得
---@return Script[]
function ClientUIBaseControl:GetScripts()
    return {}
end

---監視するキーイベントを登録
---@param eventType KeyEventType イベントタイプ
---@param callback fun() コールバック
function ClientUIBaseControl:AddKeyEventListener(eventType, callback) end

---監視中のキーイベントを解除
---@param eventType KeyEventType イベントタイプ
---@param callback fun() コールバック
function ClientUIBaseControl:RemoveKeyEventListener(eventType, callback) end

---指定したキーイベントの監視を解除
---@param eventType KeyEventType イベントタイプ
function ClientUIBaseControl:RemoveKeyEventListeners(eventType) end

---すべてのキーイベントの監視を解除
function ClientUIBaseControl:RemoveAllKeyEventListeners() end

---監視するコントローラーナビゲーションイベントを登録
---@param eventType ControllerNavigationEventType イベントタイプ
---@param callback fun() コールバック
function ClientUIBaseControl:AddNavigationEventListener(eventType, callback) end

---監視中のコントローラーナビゲーションイベントを解除
---@param eventType ControllerNavigationEventType イベントタイプ
---@param callback fun() コールバック
function ClientUIBaseControl:RemoveNavigationEventListener(eventType, callback) end

---指定したコントローラーナビゲーションイベントの監視を解除
---@param eventType ControllerNavigationEventType イベントタイプ
function ClientUIBaseControl:RemoveNavigationEventListeners(eventType) end

---すべてのコントローラーナビゲーションイベントの監視を解除
function ClientUIBaseControl:RemoveAllNavigationEventListeners() end

---指定した方向のナビゲーションモードおよびターゲットコントロールを設定
---@param navigationDir ControllerNavigationDir 指定方向
---@param navigationMode ControllerNavigationMode ナビゲーションモード
---@param navigationTarget ClientUIBaseControl? 対象コントロール
function ClientUIBaseControl:SetControllerNavigation(
    navigationDir,
    navigationMode,
    navigationTarget
)
end

--- 【★】指定した方向のナビゲーションモードおよびターゲットコントロールを取得
---
---──────────────
---
--- 実際には ClientUIBaseControl 派生クラスが返却されます。
---
--- 正しい補完を使用したい場合は、呼出側で `---@cast` を指定してください。
---
---──────────────
---
---@param navigationDir ControllerNavigationDir 指定方向
---@return ControllerNavigationMode,ClientUIBaseControl?
function ClientUIBaseControl:GetControllerNavigation(
    navigationDir
)
    return {}
end
