---@class Script
script = {}

---スクリプトがまだ存在してるかどうか
---@type boolean
script.alive = true

---スクリプトのマッピングID
---@type integer
script.scriptMappingId = 0

---スクリプトが紐づけられているオブジェクト
---@type any
script.object = nil

---スクリプトのパス
---@type string
script.path = ""

---スクリプトの有効状態
---@type boolean
script.enabled = true

---スクリプト変数を取得
---@param paramName string スクリプト変数名
---@return any
function script:GetParam(paramName) end

---スクリプト内の関数をコール
---@param funcName string 関数名
function script:Invoke(funcName, ...) end

---フレーム更新の切り替え
---@param enabled boolean true:フレーム更新あり false:フレーム更新なし
function script:EnableUpdate(enabled) end

---監視するサーバー信号を登録
---@param signalName string 信号名
---@param callback fun(signalName:string,signalParams:any[]) コールバック関数
function script:RegisterServerSignalHandler(signalName, callback) end

---監視中のサーバ信号の解除
---@param signalName string 信号名
function script:UnregisterServerSignalHandler(signalName) end

---監視するカスタム変数の登録
---@param entityType CustomVariableEntityType エンティティタイプ
---@param customVariableName string カスタム変数名
---@param callback fun(entityType:CustomVariableEntityType,customVariableName:string) コールバック関数
function script:RegisterCustomVariableChangedHandler(
    entityType,
    customVariableName,
    callback
)
end

---監視中のカスタム変数の解除
---@param entityType CustomVariableEntityType エンティティタイプ
---@param customVariableName string カスタム変数名
function script:UnregisterCustomVariableChangedHandler(
    entityType,
    customVariableName
)
end
