---@class ClientUICusorEventAreaControl : ClientUIBaseControl
---@field raycastTarget boolean ポインターのレイキャストで検出可能かどうか
ClientUICusorEventAreaControl = {}

---監視するカーソルイベントを登録
---@param eventType CursorEventType イベントタイプ
---@param callback fun(cursorEventData:CursorEventData)
function ClientUICusorEventAreaControl:AddCursorEventListener(
    eventType,
    callback
)
end

---監視中のカーソルイベントを解除
---@param eventType CursorEventType イベントタイプ
---@param callback fun(cursorEventData:CursorEventData)
function ClientUICusorEventAreaControl:RemoveCursorEventListener(
    eventType,
    callback
)
end

---指定したカーソルイベントの監視を解除
---@param eventType CursorEventType イベントタイプ
function ClientUICusorEventAreaControl:RemoveCursorEventListeners(
    eventType
)
end

---すべてのカーソルイベントの監視を解除
function ClientUICusorEventAreaControl:RemoveAllCursorEventListeners()
end

---CursorDown、CursorUp、CursorClick を順に実行
function ClientUICusorEventAreaControl:SimulateCursorClick()
end
