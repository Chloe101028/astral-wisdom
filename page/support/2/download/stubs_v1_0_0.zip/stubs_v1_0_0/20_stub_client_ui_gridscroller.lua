---@class ClientUIGridScrollerControl : ClientUIBaseControl
---@field itemCount integer アイテムの数
---@field itemPrefabIndex integer モジュールテンプレートのインデックス
---@field raycastTarget boolean ポインターのレイキャストで検出可能かどうか
---@field showScrollBar boolean スクロール可能かどうか
---@field interactable boolean スクロールバーを表示するかどうか
---@field scrollDirection ScrollDirection スクロール方向
---@field layoutConstraint ScrollLayoutConstraint 配列制限
---@field layoutConstraintFixedCount number 固定列数の時の列数
---@field scrollProgress number スクロール進行度
ClientUIGridScrollerControl = {}

---リスト項目を更新
---@param itemCount integer アイテムの数
---@param refreshCallback fun(control:ClientUIBaseControl, index:integer) コールバック
function ClientUIGridScrollerControl:RefreshItems(
    itemCount,
    refreshCallback
)
end

---リスト項目のインデックスを取得
---@param control ClientUIBaseControl UIコントロール
---@return integer
function ClientUIGridScrollerControl:GetItemIndex(
    control
)
    return 0
end

---リスト項目の幅と高さを取得
---@return number x 幅
---@return number y 高さ
function ClientUIGridScrollerControl:GetItemSize()
    return 0, 0
end

---リスト項目の水平方向および垂直方向の間隔を取得
---@return number x 水平方向
---@return number y 垂直方向
function ClientUIGridScrollerControl:GetItemSpacing()
    return 0, 0
end

---コンテンツエリアの上、下、左、右の余白を取得
---@return number top 上
---@return number bottom 下
---@return number left 左
---@return number right 右
function ClientUIGridScrollerControl:GetPadding()
    return 0, 0, 0, 0
end

---指定項目へスクロールし、指定タイプで整列
---@param index integer インデックス
---@param scrollAlignType ScrollAlignType スクロール配置タイプ
function ClientUIGridScrollerControl:ScrollToItemAt(
    index,
    scrollAlignType
)
end

---スクロールコンテンツの長さを取得
---@return number
function ClientUIGridScrollerControl:GetContentLength()
    return 0
end
