---@class ClientUIKeyHintControl : ClientUIBaseControl
---@field keyboardKeyCode KeyboardKeyCode キーボード・マウスのキー列挙値
---@field controllerKeyCode ControllerKeyCode コントローラー（パッド）のボタン列挙値
ClientUIKeyHintControl = {}
