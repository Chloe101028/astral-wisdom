---@class ClientUIAnimationControl : ClientUIBaseControl
---@field animationId integer 画面エフェクトのインデックス
---@field playSoundEffect boolean 効果音を再生するかどうか
---@field layer UIAnimationLayer レイヤー
ClientUIAnimationControl = {}

---画面エフェクトを再生する
function ClientUIAnimationControl:PlayAnimation()
end

---画面エフェクトを停止する
function ClientUIAnimationControl:StopAnimation()
end
