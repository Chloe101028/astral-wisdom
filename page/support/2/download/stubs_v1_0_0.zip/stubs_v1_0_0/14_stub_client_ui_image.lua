---@class ClientUIImageControl : ClientUIBaseControl
---@field imageSource ImageSource 画像ソース
---@field imageId integer 画像ID
---@field imageColor ColorValue カラー
---@field imageType ImageType 画像タイプ
---@field enableMask boolean  マスキングを有効にするかどうか
---@field enableSoftEdge boolean 境界線のぼかしを有効にするかどうか
---@field softEdgeMode ImageMaskSoftEdgeMode ぼかしモード
---@field softEdgeWidthX number 水平方向の境界ぼかし幅
---@field softEdgeWidthY number 垂直方向の境界ぼかし幅
---@field horizontalSoftRange number 横方向エリア範囲
---@field verticalSoftRange number 縦方向エリア範囲
---@field reverseMaskArea boolean マスクエリア反転するかどうか
---@field fillType ImageFillType 塗りつぶしの形状
---@field fillHorizontalType ImageFillHorizontalType 塗りつぶしの方向(横)
---@field fillVerticalType ImageFillVerticalType 塗りつぶしの方向(縦)
---@field fillRadial90Type ImageFillRadial90Type 塗りつぶしの開始位置(90度円軌道)
---@field fillRadialType ImageFillRadialType 塗りつぶしの開始位置(180度,360度円軌道)
---@field fillAmount number 進捗
ClientUIImageControl = {}

---画像のソースと画像IDを設定
---@param imageSource ImageSource 画像ソース
---@param imageId integer 画像ID
function ClientUIImageControl:SetImage(
    imageSource,
    imageId
)
end

---水平方向および垂直方向のぼかし幅を設定
---@param widthX number 水平方向
---@param widthY number 垂直方向
function ClientUIImageControl:SetSoftEdgeWidth(
    widthX,
    widthY
)
end

---塗りつぶしを使用しないように設定
function ClientUIImageControl:SetFillUnused() end

---水平方向の塗りつぶしを設定
---@param fillHorizontalType ImageFillHorizontalType 塗りつぶしの方向(横)
---@param fillAmount number 進捗
function ClientUIImageControl:SetFillHorizontal(
    fillHorizontalType,
    fillAmount
)
end

---垂直方向の塗りつぶしを設定
---@param fillVerticalType ImageFillVerticalType 塗りつぶしの方向(縦)
---@param fillAmount number 進捗
function ClientUIImageControl:SetFillVertical(
    fillVerticalType,
    fillAmount
)
end

---90度円軌道の塗りつぶしを設定
---@param fillRadial90Type ImageFillRadial90Type 塗りつぶしの開始位置(90度円軌道)
---@param fillAmount number 進捗
function ClientUIImageControl:SetFillRadial90(
    fillRadial90Type,
    fillAmount
)
end

---180度円軌道の塗りつぶしを設定
---@param fillRadialType ImageFillRadialType 塗りつぶしの開始位置(180度,360度円軌道)
---@param fillAmount number 進捗
function ClientUIImageControl:SetFillRadial180(
    fillRadialType,
    fillAmount
)
end

---360度円軌道の塗りつぶしを設定
---@param fillRadialType ImageFillRadialType 塗りつぶしの開始位置(180度,360度円軌道)
---@param fillAmount number 進捗
function ClientUIImageControl:SetFillRadial360(
    fillRadialType,
    fillAmount
)
end
