---@class Enum
Enum = {}

--------------------------------------------------
-- EaseType
--------------------------------------------------

---@class EaseType
---リニア
---@type EaseType
Enum.EaseType.Linear = nil

---イーズイン
---@type EaseType
Enum.EaseType.InSine = nil

---イーズアウト
---@type EaseType
Enum.EaseType.OutSine = nil

---イーズインアウト
---@type EaseType
Enum.EaseType.InOutSine = nil

---イーズイン(Sineより強い)
---@type EaseType
Enum.EaseType.InQuad = nil

---イーズアウト(Sineより強い)
---@type EaseType
Enum.EaseType.OutQuad = nil

---イーズインアウト(Sineより強い)
---@type EaseType
Enum.EaseType.InOutQuad = nil

---イーズイン(Quadより強い)
---@type EaseType
Enum.EaseType.InCubic = nil

---イーズアウト(Quadより強い)
---@type EaseType
Enum.EaseType.OutCubic = nil

---イーズインアウト(Quadより強い)
---@type EaseType
Enum.EaseType.InOutCubic = nil

---イーズイン(Cubicより強い)
---@type EaseType
Enum.EaseType.InQuart = nil

---イーズアウト(Cubicより強い)
---@type EaseType
Enum.EaseType.OutQuart = nil

---イーズインアウト(Cubicより強い)
---@type EaseType
Enum.EaseType.InOutQuart = nil

---イーズイン(Quartより強い)
---@type EaseType
Enum.EaseType.InQuint = nil

---イーズアウト(Quartより強い)
---@type EaseType
Enum.EaseType.OutQuint = nil

---イーズインアウト(Quartより強い)
---@type EaseType
Enum.EaseType.InOutQuint = nil

---イーズイン(Quintより強い)
---@type EaseType
Enum.EaseType.InExpo = nil

---イーズアウト(Quintより強い)
---@type EaseType
Enum.EaseType.OutExpo = nil

---イーズインアウト(Quintより強い)
---@type EaseType
Enum.EaseType.InOutExpo = nil

---イーズイン(Expoより加速や減速がゆるやか)
---@type EaseType
Enum.EaseType.InCirc = nil

---イーズアウト(Expoより加速や減速がゆるやか)
---@type EaseType
Enum.EaseType.OutCirc = nil

---イーズインアウト(Expoより加速や減速がゆるやか)
---@type EaseType
Enum.EaseType.InOutCirc = nil

---イーズイン(少し行き過ぎてから戻ってくる)
---@type EaseType
Enum.EaseType.InBack = nil

---イーズアウト(少し行き過ぎてから戻ってくる)
---@type EaseType
Enum.EaseType.OutBack = nil

---イーズインアウト(少し行き過ぎてから戻ってくる)
---@type EaseType
Enum.EaseType.InOutBack = nil

---イーズイン(ゴムのような動き)
---@type EaseType
Enum.EaseType.InElastic = nil

---イーズアウト(ゴムのような動き)
---@type EaseType
Enum.EaseType.OutElastic = nil

---イーズインアウト(ゴムのような動き)
---@type EaseType
Enum.EaseType.InOutElastic = nil

---イーズイン(ボールのような動き)
---@type EaseType
Enum.EaseType.InBounce = nil

---イーズアウト(ボールのような動き)
---@type EaseType
Enum.EaseType.OutBounce = nil

---イーズインアウト(ボールのような動き)
---@type EaseType
Enum.EaseType.InOutBounce = nil

--------------------------------------------------
-- CustomVariableEntityType
--------------------------------------------------

---@class CustomVariableEntityType
---ステージ
---@type CustomVariableEntityType
Enum.CustomVariableEntityType.Level = nil

---プレイヤー自身
---@type CustomVariableEntityType
Enum.CustomVariableEntityType.PlayerSelf = nil

---キャラ自身
---@type CustomVariableEntityType
Enum.CustomVariableEntityType.AvatarSelf = nil


--------------------------------------------------
-- Device
--------------------------------------------------

---@class Device
---キーボード＆マウス
---@type Device
Enum.Device.KeyboardAndMouse = nil

---モバイルタッチパネル
---@type Device
Enum.Device.Mobile = nil

---コンソールコントローラー
---@type Device
Enum.Device.Controller = nil

---モバイル用コントローラー
---@type Device
Enum.Device.MobileController = nil

--------------------------------------------------
-- StageMode
--------------------------------------------------

---@class StageMode
---キーボード＆マウス
---@type StageMode
Enum.StageMode.Beyond = nil

---モバイルタッチパネル
---@type StageMode
Enum.StageMode.Classic = nil

--------------------------------------------------
-- LanguageType
--------------------------------------------------

---@class LanguageType
---未設定
---@type LanguageType
Enum.LanguageType.LanguageNone = nil

---英語
---@type LanguageType
Enum.LanguageType.LanguageEng = nil

---簡体字中国語
---@type LanguageType
Enum.LanguageType.LanguageChs = nil

---繁体字中国語
---@type LanguageType
Enum.LanguageType.LanguageCht = nil

---フランス語
---@type LanguageType
Enum.LanguageType.LanguageFra = nil

---ドイツ語
---@type LanguageType
Enum.LanguageType.LanguageDeu = nil

---スペイン語
---@type LanguageType
Enum.LanguageType.LanguageSpa = nil

---ポルトガル語
---@type LanguageType
Enum.LanguageType.LanguagePor = nil

---ロシア語
---@type LanguageType
Enum.LanguageType.LanguageRus = nil

---日本語
---@type LanguageType
Enum.LanguageType.LanguageJpn = nil

---韓国語
---@type LanguageType
Enum.LanguageType.LanguageKor = nil

---タイ語
---@type LanguageType
Enum.LanguageType.LanguageTha = nil

---ベトナム語
---@type LanguageType
Enum.LanguageType.LanguageVie = nil

---インドネシア語
---@type LanguageType
Enum.LanguageType.LanguageInd = nil

---トルコ語
---@type LanguageType
Enum.LanguageType.LanguageTur = nil

---イタリア語
---@type LanguageType
Enum.LanguageType.LanguageIta = nil

--------------------------------------------------
-- ParamType
--------------------------------------------------

---@class ParamType
---エンティティ
---@type ParamType
Enum.ParamType.Entity = nil

---エンティティリスト
---@type ParamType
Enum.ParamType.EntityList = nil

---整数
---@type ParamType
Enum.ParamType.Int = nil

---整数リスト
---@type ParamType
Enum.ParamType.IntList = nil

---ブール値
---@type ParamType
Enum.ParamType.Bool = nil

---ブール値リスト
---@type ParamType
Enum.ParamType.BoolList = nil

---浮動小数点数
---@type ParamType
Enum.ParamType.Float = nil

---浮動小数点数リスト
---@type ParamType
Enum.ParamType.FloatList = nil

---文字列
---@type ParamType
Enum.ParamType.String = nil

---文字列リスト
---@type ParamType
Enum.ParamType.StringList = nil

---3Dベクトル
---@type ParamType
Enum.ParamType.Vector3 = nil

---3Dベクトルリスト
---@type ParamType
Enum.ParamType.Vector3List = nil

---GUID
---@type ParamType
Enum.ParamType.Guid = nil

---GUIDリスト
---@type ParamType
Enum.ParamType.GuidList = nil

---配置ID
---@type ParamType
Enum.ParamType.ConfigId = nil

---プレハブID
---@type ParamType
Enum.ParamType.PrefabId = nil

---配置IDリスト
---@type ParamType
Enum.ParamType.ConfigIdList = nil

---プレハブIDリスト
---@type ParamType
Enum.ParamType.PrefabIdList = nil

--------------------------------------------------
-- CursorEventType
--------------------------------------------------

---@class CursorEventType
---カーソルを押した時
---@type CursorEventType
Enum.CursorEventType.CursorDown = nil

---カーソルを離した時
---@type CursorEventType
Enum.CursorEventType.CursorUp = nil

---カーソルが検知エリアに入った時
---@type CursorEventType
Enum.CursorEventType.CursorEnter = nil

---カーソルが検知エリアから外れた時
---@type CursorEventType
Enum.CursorEventType.CursorExit = nil

---カーソルをドラッグ中
---@type CursorEventType
Enum.CursorEventType.CursorDrag = nil

---ドラッグ開始時
---@type CursorEventType
Enum.CursorEventType.CursorBeginDrag = nil

---ドラッグ終了時
---@type CursorEventType
Enum.CursorEventType.CursorEndDrag = nil

---クリック完了時
---@type CursorEventType
Enum.CursorEventType.CursorClick = nil

--------------------------------------------------
-- ScrollDirection
--------------------------------------------------

---@class ScrollDirection
---水平スクロール
---@type ScrollDirection
Enum.ScrollDirection.Horizontal = nil

---垂直スクロール
---@type ScrollDirection
Enum.ScrollDirection.Vertical = nil

--------------------------------------------------
-- ScrollLayoutConstraint
--------------------------------------------------

---@class ScrollLayoutConstraint
---自動折り返しレイアウト
---@type ScrollLayoutConstraint
Enum.ScrollLayoutConstraint.AutoWrap = nil

---行数または列数固定レイアウト
---@type ScrollLayoutConstraint
Enum.ScrollLayoutConstraint.Fixed = nil

--------------------------------------------------
-- ScrollAlignType
--------------------------------------------------

---@class ScrollAlignType
---下揃え
---@type ScrollAlignType
Enum.ScrollAlignType.Bottom = nil

---中央揃え
---@type ScrollAlignType
Enum.ScrollAlignType.Center = nil

---上揃え
---@type ScrollAlignType
Enum.ScrollAlignType.Top = nil

--------------------------------------------------
-- ControllerNavigationDir
--------------------------------------------------

---@class ControllerNavigationDir
---上
---@type ControllerNavigationDir
Enum.ControllerNavigationDir.Up = nil

---下
---@type ControllerNavigationDir
Enum.ControllerNavigationDir.Down = nil

---左
---@type ControllerNavigationDir
Enum.ControllerNavigationDir.Left = nil

---右
---@type ControllerNavigationDir
Enum.ControllerNavigationDir.Right = nil

--------------------------------------------------
-- ControllerNavigationEventType
--------------------------------------------------

---@class ControllerNavigationEventType
---決定
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.Confirm = nil

---キャンセル
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.Cancel = nil

---フォーカス
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.Focus = nil

---フォーカスアウト
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.LostFocus = nil

---右スティック上
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.RightStickUp = nil

---右スティック下
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.RightStickDown = nil

---右スティック右
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.RightStickRight = nil

---右スティック左
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.RightStickLeft = nil

---左スティック上
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.LeftStickUp = nil

---左スティック下
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.LeftStickDown = nil

---左スティック右
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.LeftStickRight = nil

---左スティック左
---@type ControllerNavigationEventType
Enum.ControllerNavigationEventType.LeftStickLeft = nil

--------------------------------------------------
-- ControllerNavigationMode
--------------------------------------------------

---@class ControllerNavigationMode
---ナビゲーションなし
---@type ControllerNavigationMode
Enum.ControllerNavigationMode.None = nil

---最も近いモジュールへ移動
---@type ControllerNavigationMode
Enum.ControllerNavigationMode.NearestControl = nil

---指定したモジュールへ移動
---@type ControllerNavigationMode
Enum.ControllerNavigationMode.Specified = nil

--------------------------------------------------
-- TextHorizontalAlignment
--------------------------------------------------

---@class TextHorizontalAlignment
---左揃え
---@type TextHorizontalAlignment
Enum.TextHorizontalAlignment.Left = nil

---	中央揃え(水平方向)
---@type TextHorizontalAlignment
Enum.TextHorizontalAlignment.Middle = nil

---	右揃え
---@type TextHorizontalAlignment
Enum.TextHorizontalAlignment.Right = nil

--------------------------------------------------
-- TextVerticalAlignment
--------------------------------------------------

---@class TextVerticalAlignment
---上揃え
---@type TextVerticalAlignment
Enum.TextVerticalAlignment.Top = nil

---	中央揃え(垂直方向)
---@type TextVerticalAlignment
Enum.TextVerticalAlignment.Middle = nil

---	下揃え
---@type TextVerticalAlignment
Enum.TextVerticalAlignment.Bottom = nil

--------------------------------------------------
-- ImageType
--------------------------------------------------

---@class ImageType
---基礎
---@type ImageType
Enum.ImageType.Basic = nil

---	伸縮
---@type ImageType
Enum.ImageType.Stretch = nil

--------------------------------------------------
-- ImageSource
--------------------------------------------------

---@class ImageSource
---静的参照
---@type ImageSource
Enum.ImageSource.StaticReference = nil

---アイテム
---@type ImageSource
Enum.ImageSource.Item = nil

---装備
---@type ImageSource
Enum.ImageSource.Equipment = nil

---スキル
---@type ImageSource
Enum.ImageSource.Skill = nil

---ユニット状態
---@type ImageSource
Enum.ImageSource.UnitStatus = nil

---陣営
---@type ImageSource
Enum.ImageSource.Faction = nil

---通貨
---@type ImageSource
Enum.ImageSource.Currency = nil

---プレハブ
---@type ImageSource
Enum.ImageSource.Prefab = nil

--------------------------------------------------
-- ImageFillType
--------------------------------------------------

---@class ImageFillType
---進捗に応じた塗りつぶしを使用しない
---@type ImageFillType
Enum.ImageFillType.Unused = nil

---水平方向
---@type ImageFillType
Enum.ImageFillType.Horizontal = nil

---垂直方向
---@type ImageFillType
Enum.ImageFillType.Vertical = nil

---90度円軌道
---@type ImageFillType
Enum.ImageFillType.Radial90 = nil

---180度円軌道
---@type ImageFillType
Enum.ImageFillType.Radial180 = nil

---360度円軌道
---@type ImageFillType
Enum.ImageFillType.Radial360 = nil

--------------------------------------------------
-- ImageFillHorizontalType
--------------------------------------------------

---@class ImageFillHorizontalType
---左から右
---@type ImageFillHorizontalType
Enum.ImageFillHorizontalType.Left = nil

---右から左
---@type ImageFillHorizontalType
Enum.ImageFillHorizontalType.Right = nil

--------------------------------------------------
-- ImageFillVerticalType
--------------------------------------------------

---@class ImageFillVerticalType
---下から上
---@type ImageFillVerticalType
Enum.ImageFillVerticalType.Bottom = nil

---上から下
---@type ImageFillVerticalType
Enum.ImageFillVerticalType.Top = nil

--------------------------------------------------
-- ImageFillRadial90Type
--------------------------------------------------

---@class ImageFillRadial90Type
---左下
---@type ImageFillRadial90Type
Enum.ImageFillRadial90Type.BottomLeft = nil

---左上
---@type ImageFillRadial90Type
Enum.ImageFillRadial90Type.TopLeft = nil

---右上
---@type ImageFillRadial90Type
Enum.ImageFillRadial90Type.TopRight = nil

---右下
---@type ImageFillRadial90Type
Enum.ImageFillRadial90Type.BottomRight = nil

--------------------------------------------------
-- ImageFillRadialType
--------------------------------------------------

---@class ImageFillRadialType
---下
---@type ImageFillRadialType
Enum.ImageFillRadialType.Bottom = nil

---左
---@type ImageFillRadialType
Enum.ImageFillRadialType.Left = nil

---上
---@type ImageFillRadialType
Enum.ImageFillRadialType.Top = nil

---右
---@type ImageFillRadialType
Enum.ImageFillRadialType.Right = nil

--------------------------------------------------
-- ImageMaskSoftEdgeMode
--------------------------------------------------

---@class ImageMaskSoftEdgeMode
---ぼかしモード：パーセンテージ
---@type ImageMaskSoftEdgeMode
Enum.ImageMaskSoftEdgeMode.Percentage = nil

---ぼかしモード：ピクセル
---@type ImageMaskSoftEdgeMode
Enum.ImageMaskSoftEdgeMode.Pixel = nil

--------------------------------------------------
-- UIAnimationLayer
--------------------------------------------------

---@class UIAnimationLayer
---全モジュールより上
---@type UIAnimationLayer
Enum.UIAnimationLayer.AboveAllControls = nil

---全モジュールより下
---@type UIAnimationLayer
Enum.UIAnimationLayer.PBeloBelowAllControlswAllControlsixel = nil
